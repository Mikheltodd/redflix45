package co.g2m2e1.redflix45;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Redflix45ApplicationTests {

	@Test
	void contextLoads() {
	}

}
